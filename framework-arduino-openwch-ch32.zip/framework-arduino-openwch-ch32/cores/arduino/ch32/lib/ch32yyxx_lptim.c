#if defined(CH32L10x)
#include "ch32l103_lptim.c"
#endif