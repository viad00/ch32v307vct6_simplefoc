#ifndef __CH32YYXX_LPTIM_H_
#define __CH32YYXX_LPTIM_H_

#if defined(CH32L10x)
#include "ch32l103_lptim.h"
#endif

#endif /* __CH32YYXX_ETH_H_ */