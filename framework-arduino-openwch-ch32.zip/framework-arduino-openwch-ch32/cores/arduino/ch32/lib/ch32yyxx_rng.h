#ifndef __CH32YYXX_RNG_H_
#define __CH32YYXX_RNG_H_

#if defined(CH32V30x) || defined(CH32V30x_C)
#include "ch32v30x_rng.h"
#endif

#endif  /* __CH32YYXX_RNG_H_ */